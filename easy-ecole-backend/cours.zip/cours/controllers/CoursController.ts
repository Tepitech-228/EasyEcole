import { Request, Response } from "express";
import { CountOptions, FindOptions, InferAttributes } from "sequelize";
import { RolesUtilisateur } from "../../../core/enums/RolesUtilisateur";
import { Cours } from "../models/Cours";

export default class CoursController {

    constructor() { }

    static async getAllCours(req: Request, res: Response): Promise<Response> {
        let options: FindOptions<InferAttributes<Cours>> = {}
        if(req.query.parcoursId) {
            options = {
                where: {parcoursId: req.query.parcoursId as string}
            }
        }

        try {
            let cours: Cours[];
            cours = await Cours.findAll(options);

            return res.status(200).send(cours);
        } catch (error) {
            return res.status(500).json({ success: false, error: error });
        }
    }

    static async getCours(req: Request, res: Response): Promise<Response> {
        let options: FindOptions<InferAttributes<Cours>> = {}
        options = { where: { id: req.params.id }, include: [Cours.associations.enseignant] }

        try {
            const cours: Cours | null = await Cours.findOne(options);

            if (cours == null)
                return res.status(404).json({ success: false, message: "Cours non trouvé" });

            return res.status(200).send(cours);
        } catch (error) {
            return res.status(500).json({ success: false, error: error });
        }
    }

    static async createCours(req: Request, res: Response): Promise<Response | null> {

        if ((req as any).utilisateurRole == RolesUtilisateur.APPRENANT) {
            return res.status(403).json({ success: false })
        }

        let cours: Cours | null = await Cours.findOne({ where: { code: req.body.code, parcoursId: req.body.parcoursId } });

        if (cours != null) {
            return res.status(400).json({ success: false, alreadyExists: true });
        }
        else {
            let cours: Cours = new Cours();
            cours.code = req.body.code
            cours.intitule = req.body.intitule
            cours.credit = req.body.credit
            cours.description = req.body.description
            cours.annee = req.body.annee
            cours.semestre = req.body.semestre
            cours.classeId = req.body.classeId
            cours.parcoursId = req.body.parcoursId
            cours.enseignantId = req.body.enseignantId

            await cours.save()
                .then((cours) => {
                    return res.status(201).send(cours);
                })
                .catch((error) => {
                    return res.status(400).json({ success: false, error: error });
                });
        }
        return null
    }

    static async updateCours(req: Request, res: Response): Promise<Response | null> {
        let options: FindOptions<InferAttributes<Cours>> = {}
        if ((req as any).utilisateurRole == RolesUtilisateur.APPRENANT) {
            return res.status(403).json({ success: false })
        }
        else if ((req as any).utilisateurRole == RolesUtilisateur.INSTITUTION) {
            options = { where: { id: req.params.id } }
        }

        let cours: Cours | null = await Cours.findOne(options);
        if (cours != null) {

            if (cours.code != req.body.code && await Cours.findOne({ where: { code: req.body.code, parcoursId: req.body.parcoursId } }) != null) {
                return res.status(400).json({ success: false, alreadyExists: true });
            }
            else {

                await cours.update({
                    code: req.body.code,
                    intitule: req.body.intitule,
                    credit: req.body.credit,
                    description: req.body.description,
                    annee: req.body.annee,
                    semestre: req.body.semestre,
                    classeId: req.body.classeId,
                    parcoursId: req.body.parcoursId,
                    enseignantId: req.body.enseignantId,
                })
                    .then(async (cours) => {
                        return res.status(200).send(cours);
                    })
                    .catch((error) => {
                        return res.status(400).json({ success: false, error: error });
                    });
            }
        }
        else {
            return res.status(404).json({ success: false, message: "Cours non trouvé" });
        }

        return null
    }

    static async deleteCours(req: Request, res: Response): Promise<Response | null> {
        let options: FindOptions<InferAttributes<Cours>> = {}
        if ((req as any).utilisateurRole == RolesUtilisateur.APPRENANT) {
            return res.status(403).json({ success: false })
        }
        else if ((req as any).utilisateurRole == RolesUtilisateur.INSTITUTION) {
            options = { where: { id: req.params.id } }
        }

        let cours: Cours | null = await Cours.findOne({ where: { id: req.params.id } });
        if (cours) {
            await cours.destroy()
                .then(() => {
                    return res.status(200).json({ success: true, message: "Cours supprimé" });
                })
                .catch((error) => {
                    return res.status(500).json({ success: false, error: error });
                });
        }
        else {
            return res.status(404).json({ success: false, message: "Cours non trouvé" });
        }

        return null
    }

    static async getCount(req: Request, res: Response): Promise<Response | null> {
        let options: CountOptions<InferAttributes<Cours>> = {}

        if ((req as any).utilisateurRole == RolesUtilisateur.APPRENANT) {
            return res.status(403).json({ success: false })
        }

        await Cours.count(options)
            .then((value) => {
                return res.status(200).json({ success: true, count: value });
            })
            .catch((error) => {
                return res.status(500).json({ success: false, error: error });
            });

        return null
    }
}