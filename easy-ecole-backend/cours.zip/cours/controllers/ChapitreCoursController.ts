import { Request, Response } from "express";
import { CountOptions, FindOptions, InferAttributes } from "sequelize";
import { RolesUtilisateur } from "../../../core/enums/RolesUtilisateur";
import { ChapitreCours } from "../models/ChapitreCours";

export default class ChapitreCoursController {

    constructor() { }

    static async getAllChapitresCours(req: Request, res: Response): Promise<Response> {
        let options: FindOptions<InferAttributes<ChapitreCours>> = {
            include: [ChapitreCours.associations.cours]
        }

        try {
            let chapitrecours: ChapitreCours[];
            chapitrecours = await ChapitreCours.findAll(options);

            return res.status(200).send(chapitrecours);
        } catch (error) {
            return res.status(500).json({ success: false, error: error });
        }
    }

    static async getChapitreCours(req: Request, res: Response): Promise<Response> {
        let options: FindOptions<InferAttributes<ChapitreCours>> = {}
        options = { where: { id: req.params.id }, include: [ChapitreCours.associations.cours, ChapitreCours.associations.ressources] }

        try {
            const chapitrecours: ChapitreCours | null = await ChapitreCours.findOne(options);

            if (chapitrecours == null)
                return res.status(404).json({ success: false, message: "ChapitreCours non trouvé" });

            return res.status(200).send(chapitrecours);
        } catch (error) {
            return res.status(500).json({ success: false, error: error });
        }
    }

    static async createChapitreCours(req: Request, res: Response): Promise<Response | null> {

        if ((req as any).utilisateurRole == RolesUtilisateur.APPRENANT) {
            return res.status(403).json({ success: false })
        }

        let chapitrecours: ChapitreCours | null = await ChapitreCours.findOne({ where: { titre: req.body.titre } });

        if (chapitrecours != null) {
            return res.status(400).json({ success: false, alreadyExists: true });
        }
        else {
            let chapitrecours: ChapitreCours = new ChapitreCours();
            chapitrecours.titre = req.body.titre
            chapitrecours.description = req.body.description
            chapitrecours.coursId = req.body.coursId

            await chapitrecours.save()
                .then((chapitrecours) => {
                    return res.status(201).send(chapitrecours);
                })
                .catch((error) => {
                    return res.status(400).json({ success: false, error: error });
                });
        }
        return null
    }

    static async updateChapitreCours(req: Request, res: Response): Promise<Response | null> {
        let options: FindOptions<InferAttributes<ChapitreCours>> = {}
        if ((req as any).utilisateurRole == RolesUtilisateur.APPRENANT) {
            return res.status(403).json({ success: false })
        }
        else if ((req as any).utilisateurRole == RolesUtilisateur.INSTITUTION) {
            options = { where: { id: req.params.id } }
        }

        let chapitrecours: ChapitreCours | null = await ChapitreCours.findOne(options);
        if (chapitrecours != null) {

            if (await ChapitreCours.findOne({ where: { titre: req.body.titre } }) != null) {
                return res.status(400).json({ success: false, alreadyExists: true });
            }
            else {

                await chapitrecours.update({
                    titre: req.body.titre,
                    description: req.body.description,
                    coursId: req.body.coursId,
                })
                    .then(async (chapitrecours) => {
                        return res.status(200).send(chapitrecours);
                    })
                    .catch((error) => {
                        return res.status(400).json({ success: false, error: error });
                    });
            }
        }
        else {
            return res.status(404).json({ success: false, message: "ChapitreCours non trouvé" });
        }

        return null
    }

    static async deleteChapitreCours(req: Request, res: Response): Promise<Response | null> {
        let options: FindOptions<InferAttributes<ChapitreCours>> = {}
        if ((req as any).utilisateurRole == RolesUtilisateur.APPRENANT) {
            return res.status(403).json({ success: false })
        }
        else if ((req as any).utilisateurRole == RolesUtilisateur.INSTITUTION) {
            options = { where: { id: req.params.id } }
        }

        let chapitrecours: ChapitreCours | null = await ChapitreCours.findOne({ where: { id: req.params.id } });
        if (chapitrecours) {
            await chapitrecours.destroy()
                .then(() => {
                    return res.status(200).json({ success: true, message: "ChapitreCours supprimé" });
                })
                .catch((error) => {
                    return res.status(500).json({ success: false, error: error });
                });
        }
        else {
            return res.status(404).json({ success: false, message: "ChapitreCours non trouvé" });
        }

        return null
    }

    static async getCount(req: Request, res: Response): Promise<Response | null> {
        let options: CountOptions<InferAttributes<ChapitreCours>> = {}

        if ((req as any).utilisateurRole == RolesUtilisateur.APPRENANT) {
            return res.status(403).json({ success: false })
        }

        await ChapitreCours.count(options)
            .then((value) => {
                return res.status(200).json({ success: true, count: value });
            })
            .catch((error) => {
                return res.status(500).json({ success: false, error: error });
            });

        return null
    }
}