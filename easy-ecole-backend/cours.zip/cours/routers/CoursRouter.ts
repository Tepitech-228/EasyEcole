import express from "express"

import CoursController from "../controllers/CoursController"
import { AuthInstitution } from "../../../core/middlewares/AuthInstitution";

const router = express.Router()

router
    .get('/', CoursController.getAllCours)
    .post('/', [AuthInstitution], CoursController.createCours)
    .get('/:id', CoursController.getCours)
    .put('/:id', [AuthInstitution], CoursController.updateCours)
    .delete('/:id', [AuthInstitution], CoursController.deleteCours)
    .get('/statistics/count', [AuthInstitution], CoursController.getCount)

export default router