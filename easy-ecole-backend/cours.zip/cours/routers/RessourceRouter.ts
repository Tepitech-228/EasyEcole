import express from "express"

import RessourceController from "../controllers/RessourceController"
import { AuthInstitution } from "../../../core/middlewares/AuthInstitution";

const router = express.Router()

router
    .get('/', RessourceController.getAllRessources)
    .post('/', [AuthInstitution], RessourceController.createRessource)
    .get('/:id', RessourceController.getRessource)
    .put('/:id', [AuthInstitution], RessourceController.updateRessource)
    .delete('/:id', [AuthInstitution], RessourceController.deleteRessource)
    .get('/statistics/count', [AuthInstitution], RessourceController.getCount)

export default router