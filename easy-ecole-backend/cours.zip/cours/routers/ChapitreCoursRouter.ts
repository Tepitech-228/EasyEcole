import express from "express"

import ChapitreCoursController from "../controllers/ChapitreCoursController"
import { AuthInstitution } from "../../../core/middlewares/AuthInstitution";

const router = express.Router()

router
    .get('/', ChapitreCoursController.getAllChapitresCours)
    .post('/', [AuthInstitution], ChapitreCoursController.createChapitreCours)
    .get('/:id', ChapitreCoursController.getChapitreCours)
    .put('/:id', [AuthInstitution], ChapitreCoursController.updateChapitreCours)
    .delete('/:id', [AuthInstitution], ChapitreCoursController.deleteChapitreCours)
    .get('/statistics/count', [AuthInstitution], ChapitreCoursController.getCount)

export default router