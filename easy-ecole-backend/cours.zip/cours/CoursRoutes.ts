require("./models/_associations")
import express from "express";
import Authenticate from "../../core/middlewares/Authenticate";
import CoursRouter from "./routers/CoursRouter";
import ParcoursRouter from "./routers/ParcoursRouter";
import ChapitreCoursRouter from "./routers/ChapitreCoursRouter";
import RessourceRouter from "./routers/RessourceRouter";
import NiveauEtudeRouter from "./routers/NiveauEtudeRouter";

const router = express.Router();

router
    .use('/cours', [Authenticate], CoursRouter)
    .use('/parcours', [Authenticate], ParcoursRouter)
    .use('/niveauxEtude', [Authenticate], NiveauEtudeRouter)
    .use('/chapitresCours', [Authenticate], ChapitreCoursRouter)
    .use('/ressources', [Authenticate], RessourceRouter)

export default router;