export const MODULE_TABLE_PREFIX: string = 'cou_'
export const MODULE_MODEL_PREFIX: string = 'Cou'