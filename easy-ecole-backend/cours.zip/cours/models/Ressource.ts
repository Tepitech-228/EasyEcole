import { Model, InferAttributes, InferCreationAttributes, CreationOptional, DataTypes, ForeignKey, NonAttribute, Association } from "sequelize";
import { DatabaseConnection } from "../../../core/helpers/DatabaseConnection";
import { Classe } from "./Classe";
import { Cours } from "./Cours";
import { MODULE_MODEL_PREFIX, MODULE_TABLE_PREFIX } from "../CoursModule";
import { ChapitreCours } from "./ChapitreCours";

export class Ressource extends Model<InferAttributes<Ressource>, InferCreationAttributes<Ressource>> {
  declare id: CreationOptional<string>
  declare titre: string
  declare description: CreationOptional<string>
  declare type: CreationOptional<string>
  declare nomFichier: string
  declare chapitreCoursId?: ForeignKey<ChapitreCours['id']>
  declare chapitreCours?: NonAttribute<ChapitreCours>

  declare readonly createdAt: CreationOptional<Date>
  declare readonly updatedAt: CreationOptional<Date>

  declare static associations: {
    classe: Association<Ressource, Classe>
    chapitreCours: Association<Ressource, ChapitreCours>
  };
}

Ressource.init({
  id: {
    type: DataTypes.INTEGER.UNSIGNED,
    autoIncrement: true,
    primaryKey: true
  },
  titre: {
    type: new DataTypes.STRING,
    allowNull: false
  },
  description: {
    type: new DataTypes.STRING,
    allowNull: true
  },
  type: {
    type: new DataTypes.STRING,
    allowNull: true
  },
  nomFichier: {
    type: new DataTypes.STRING,
    allowNull: false
  },
  createdAt: DataTypes.DATE,
  updatedAt: DataTypes.DATE,
}, {
  sequelize: DatabaseConnection.getInstance().sequelize,
  paranoid: true,
  modelName: MODULE_MODEL_PREFIX + 'Ressource',
  tableName: MODULE_TABLE_PREFIX + 'ressources',
  timestamps: true
})