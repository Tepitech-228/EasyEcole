// import { Cours } from "./Cours";
// import { NiveauEtude } from "./NiveauEtude";
// import { Parcours } from "./Parcours";
// import { Classe } from "./Classe";
// import { Enseignant } from "../../auth/models/Enseignant";
// import { Ressource } from "./Ressource";
// import { ChapitreCours } from "./ChapitreCours";

// // Cours - Enseignant
// Enseignant.hasMany(Cours, { foreignKey: 'enseignantId', as: 'cours' })
// Cours.belongsTo(Enseignant, { as: 'enseignant', foreignKey: 'enseignantId' })

// // Cours - Parcours
// Parcours.hasMany(Cours, { foreignKey: 'parcoursId', as: 'cours' })
// Cours.belongsTo(Parcours, { as: 'parcours', foreignKey: 'parcoursId' })

// // Cours - ChapitreCours
// Cours.hasMany(ChapitreCours, { foreignKey: 'coursId', as: 'chapitresCours' })
// ChapitreCours.belongsTo(Cours, { as: 'cours', foreignKey: 'coursId' })

// // ChapitreCours - Ressource
// ChapitreCours.hasMany(Ressource, { foreignKey: 'chapitreCoursId', as: 'ressources' })
// Ressource.belongsTo(ChapitreCours, { as: 'chapitreCours', foreignKey: 'chapitreCoursId' })

// // NiveauEtude - Classe
// NiveauEtude.hasMany(Classe, { foreignKey: 'niveauEtudeId', as: 'classes' })
// Classe.belongsTo(NiveauEtude, { as: 'niveauEtude', foreignKey: 'niveauEtudeId' })

// // NiveauEtude - Parcours
// NiveauEtude.hasMany(Parcours, { foreignKey: 'niveauEtudeId', as: 'parcours' })
// Parcours.belongsTo(NiveauEtude, { as: 'niveauEtude', foreignKey: 'niveauEtudeId' })

// // Ense